document.getElementById("payBtn").addEventListener("click", async () => {
    const res = await fetch("http://localhost:5000/api/pay", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ amount: 100, email: "test@example.com" })
    });

    const data = await res.json();
    if (data.clientSecret) alert("Payment Successful!");
});
