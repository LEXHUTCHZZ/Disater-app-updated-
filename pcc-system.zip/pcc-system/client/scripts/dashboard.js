async function loadGrades() {
    const userId = "some-user-id";
    const res = await fetch(`http://localhost:5000/api/grades/${userId}`);
    const grades = await res.json();
    document.getElementById("grades").innerHTML = grades.map(g => `<li>${g.course}: ${g.grade}</li>`).join("");
}
loadGrades();
