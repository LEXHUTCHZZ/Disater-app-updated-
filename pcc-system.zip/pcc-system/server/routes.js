const express = require("express");
const router = express.Router();
const User = require("./models/userModel");
const Grade = require("./models/gradeModel");
const { processPayment } = require("./payment");

router.post("/register", async (req, res) => {
    const { name, email, password } = req.body;
    try {
        const user = new User({ name, email, password });
        await user.save();
        res.json({ message: "User registered successfully" });
    } catch (err) {
        res.status(400).json({ error: err.message });
    }
});

router.post("/login", async (req, res) => {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (user && user.password === password) {
        res.json({ message: "Login successful", user });
    } else {
        res.status(400).json({ message: "Invalid credentials" });
    }
});

router.get("/grades/:userId", async (req, res) => {
    const grades = await Grade.find({ studentId: req.params.userId });
    res.json(grades);
});

router.post("/pay", processPayment);

module.exports = router;
