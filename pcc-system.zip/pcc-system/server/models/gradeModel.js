const mongoose = require("mongoose");

const GradeSchema = new mongoose.Schema({
    studentId: String,
    course: String,
    grade: String
});

module.exports = mongoose.model("Grade", GradeSchema);
